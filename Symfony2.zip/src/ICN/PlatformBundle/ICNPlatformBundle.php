<?php

namespace ICN\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ICNPlatformBundle extends Bundle
{
}
